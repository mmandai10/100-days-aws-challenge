package com.aws100days.day23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day23TaskApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day23TaskApiApplication.class, args);
	}

}
