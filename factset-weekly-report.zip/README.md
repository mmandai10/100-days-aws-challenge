# 📊 FactSet Earnings Insight Weekly Summary

毎週月曜日朝に、FactSetのS&P 500 Earnings Insightレポートを自動取得し、Claude APIでサマリーを作成してメール配信するシステムです。

## 🚀 セットアップ手順

### 1. リポジトリをフォークまたはクローン

```bash
git clone https://github.com/YOUR_USERNAME/factset-weekly-report.git
cd factset-weekly-report
```

### 2. GitHub Secretsの設定

GitHubリポジトリの **Settings → Secrets and variables → Actions** で以下を設定：

| Secret名 | 説明 | 例 |
|----------|------|-----|
| `ANTHROPIC_API_KEY` | Claude APIキー（必須） | `sk-ant-api03-xxxxx` |
| `SMTP_SERVER` | SMTPサーバー | `smtp.gmail.com` |
| `SMTP_PORT` | SMTPポート | `587` |
| `SMTP_USER` | 送信元メールアドレス | `your-email@gmail.com` |
| `SMTP_PASSWORD` | アプリパスワード | `xxxx xxxx xxxx xxxx` |
| `TO_EMAIL` | 送信先メールアドレス | `recipient@example.com` |

### 3. Gmailの場合のアプリパスワード取得

1. Google アカウント → セキュリティ
2. 「2段階認証プロセス」を有効化
3. 「アプリパスワード」を生成
4. 生成された16文字のパスワードを `SMTP_PASSWORD` に設定

### 4. 手動テスト実行

1. GitHubリポジトリの **Actions** タブへ
2. 「FactSet Weekly Earnings Report Summary」を選択
3. 「Run workflow」をクリック

## 📅 自動実行スケジュール

- **毎週月曜日 朝8:00（日本時間）** に自動実行
- レポートは `reports/` フォルダに保存
- メールでサマリーが配信

## 📁 ファイル構成

```
factset-weekly-report/
├── .github/
│   └── workflows/
│       └── factset_weekly.yml  # GitHub Actionsワークフロー
├── scripts/
│   └── factset_summary.py      # メインスクリプト
├── reports/                    # 生成されたレポート（自動作成）
└── README.md
```

## 📋 出力サンプル

```markdown
# 📊 FactSet Earnings Insight サマリー (2026/01/24)

## Q4 2025 決算シーズン進捗
- **発表済み**: S&P 500の13%
- **EPSビート率**: 75%（5年平均78%を下回る）
- **決算成長率**: 8.2%（前年同期比、10四半期連続増益）

## Magnificent 7 の貢献
- トップ5貢献企業: NVIDIA, Boeing, Alphabet, Micron, Microsoft
- M7の利益成長率: +20.3%
- その他493社: +4.1%

## 今週の注目決算
- Apple, Meta, Microsoft, Tesla（1/26週）
```

## 🔧 カスタマイズ

### 実行時間の変更

`.github/workflows/factset_weekly.yml` の cron 設定を変更：

```yaml
schedule:
  - cron: '0 23 * * 0'  # UTC日曜23:00 = 日本時間月曜08:00
```

[Crontab Guru](https://crontab.guru/) で確認できます。

### サマリー内容の変更

`scripts/factset_summary.py` の `generate_summary_with_claude()` 内のプロンプトを編集。

## ⚠️ 注意事項

- FactSetのPDF URLは日付ベースのため、形式が変更されると動作しない可能性あり
- Claude API使用量に注意（1回あたり約$0.01-0.05）
- Gmailの1日あたり送信上限は500通

## 📝 ライセンス

MIT License

## 🙏 謝辞

- [FactSet](https://www.factset.com/) - Earnings Insightレポート
- [Anthropic](https://www.anthropic.com/) - Claude API
