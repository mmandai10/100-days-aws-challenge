package com.aws100days.day22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day22SpringbootHelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day22SpringbootHelloApplication.class, args);
	}

}
